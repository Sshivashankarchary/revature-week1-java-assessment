package assessment1;

import java.util.Scanner;

public class GrossAndDozens {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number of eggs");
	int a=sc.nextInt();
	sc.close();
	int b=0;
	b=a/144;
	System.out.println("grosses:-"+b);
	a=a%144;
	b=a/12;
	System.out.println("dozens:-"+b);
	a=a%12;
	System.out.println("no.of eggs that we have:-"+a);
	}
}
