package assessment1.payment;

public interface Worker2 {
int pay(int weeks);
}
class DailyWorker implements Worker2{
int wageDay=100;
	@Override
	public int pay(int weeks) {
		// TODO Auto-generated method stub
		return weeks*7*wageDay;
	}
	
}
class SalaryPerWeek implements Worker2{
int salaryPerWeek=500;
	@Override
	public int pay(int weeks) {
		// TODO Auto-generated method stub
		return weeks*salaryPerWeek;
	}
	
}
