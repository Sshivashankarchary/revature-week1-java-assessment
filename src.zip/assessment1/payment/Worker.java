package assessment1.payment;

public class Worker {
String name;
int days;
String workerType;
public Worker(String name, int days, String workerType) {
	super();
	this.name = name;
	this.days = days;
	this.workerType = workerType;
}
@Override
public String toString() {
	return "Worker [name=" + name + ", days=" + days + ", workerType=" + workerType + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getDays() {
	return days;
}
public void setDays(int days) {
	this.days = days;
}
public String getWorkerType() {
	return workerType;
}
public void setWorkerType(String workerType) {
	this.workerType = workerType;
}

}
