package assessment1.payment;

import java.util.Comparator;

public class SalaryComparator implements Comparator {

	public int compare(Worker o1, Worker o2) {
		if(o1.getDays()>o2.getDays())
		return 1;
		else
		return -1;
	}

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}
}
