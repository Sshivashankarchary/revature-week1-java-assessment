package assessment1.payment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Sorting {
public static void main(String[] args) {
	Worker w1=new Worker("shiva",5,"D");
	List<Worker> w2=new ArrayList<Worker>();
	w2.add(w1);
	w2.add(new Worker("shankar",1,"W"));
	w2.add(new Worker("anil",3,"W"));
	w2.add(new Worker("vivek",7,"W"));
	w2.add(new Worker("nani",2,"D"));
	w2.add(new Worker("bittu",6,"W"));
	Iterator<Worker> iterator=w2.iterator();
	System.out.println("before sorting------");
	while(iterator.hasNext()) {
		Worker temp=iterator.next();
		System.out.println(temp);
		}
	Collections.sort(w2,new SalaryComparator());
	Iterator<Worker> i=w2.iterator();
	System.out.println("after sorting--------");
	while(i.hasNext()) {
		Worker temp=i.next();
		System.out.println(temp);
		}
	}
}
