package assessment1.material;

public class Lapi extends Inventor {
int quantity=1000;
int lolq=3;
String processor;
String name;
public Lapi() {
	super();
	this.quantity = quantity;
	this.lolq = lolq;
	this.processor = processor;
	this.name = name;
}
public Lapi(String string, String string2) {
	
}
@Override
public String toString() {
	return "Lapi [quantity=" + quantity + ", lolq=" + lolq + ", processor=" + processor + ", name=" + name + "]";
}
public void out(int q) {
	if(q<quantity && q> lolq)
		System.out.println("order is placing");
	else if(q<lolq)
		System.out.println("request meterial");
	else {
		System.out.println("not there");
	}
}
}
