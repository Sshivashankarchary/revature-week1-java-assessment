package assessment1.material;

import java.util.Scanner;

public class Order {

	public static void main(String[] args) {
    Lapi l=new Lapi("hp","i10");
    Lapi l1=new Lapi("apple","i6");
    Lapi l3=new Lapi("lenovo","i9");
    Lapi l4=new Lapi("dell","i5");
    Accessories a1=new Accessories("purse",400);
    Accessories a2=new Accessories("socks",2500);
    Accessories a3=new Accessories("glasses",54000);
    Accessories a4=new Accessories("watch",69800);
    System.out.println("what we want...1).lapi or \n 2).Accessories");
    Scanner sc=new Scanner(System.in);
    int i=sc.nextInt();
    System.out.println("how many do you want..");
    int quantity=sc.nextInt();
    switch(i) {
    case 1:
    	Lapi o=new Lapi();
    	o.out(quantity);
    	break;
    case 2:
    	Accessories o2=new Accessories();
    	o2.out(quantity);
    	break;
    default:
    	System.out.println("enter 1 or 2");
    	break;
    }
	}

}
