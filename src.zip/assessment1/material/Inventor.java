package assessment1.material;

public class Inventor {
int quantity;
int lolq;
}
