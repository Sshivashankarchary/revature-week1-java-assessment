/*package assessment1;

import java.util.Scanner;

public class Taxslabs {*/
package assesment1;

import java.util.Scanner;
	 class Taxslabs
	 {
		 
		public static void main(String[] args) 
		{
	     Scanner sc= new Scanner(System.in);   
	     System.out.println("Enter Gender as M or F : ");  
	     String gender= sc.nextLine();             
	     //System.out.println("You have entered: "+gender);        
			
	     System.out.println( "INCOME: " );
	     int Income = sc.nextInt();
	     //System.out.println("You have entered: "+Income);
	     
	     System.out.println( "year: " );
	     int year = sc.nextInt();
	     //System.out.println("You have entered: "+year);
	  
	     	if(gender.equals("M"))
	     	{
	     		if(year!=2011 && year!=2012)
	     		{
	     			if(Income<=180000)
	     			{
	     				System.out.println("NO TAX");
	     			}
	     			else if(Income>=180001 && Income<=500000)
	     			{
	     				System.out.println("10%");
	     			}
	     			else if(Income>=500001 && Income<800000)
	     			{
	     				System.out.println("20%");
	     			}
	     			else if(Income>=800000)
	     			{
	     				System.out.println("30%");
	     			}
	     		}
	     	}
	     	 
	     
	     else if (gender.equals("F"))
			{
				if(year==2011 || year==2012)
				{
					if(Income>=190000)
					{
						System.out.println("NO TAX");
					}
					else if(Income>=190001 && Income<=500000)
					{
						System.out.println("10%");
					}
					else if(Income>=500001 && Income<800000)
					{
						System.out.println("20%");
					}
					else if(Income>=800000)
					{
						System.out.println("30%");
					}
				}
			}
	     
		}

	}
	/*
	 * public void tax(int gen,int inc) { if(inc<=500000) if(gen==1) { if(inc>=0 &&
	 * inc<=180000) System.out.println(0); else if(inc>=180001 && inc<=500000)
	 * System.out.println("tax is:-"+inc*0.1); else
	 * System.out.println("enter positive number");} else if(gen==2) { if(inc>=0 &&
	 * inc<=190000) System.out.println(0); else if(inc>=190001 && inc<=500000)
	 * System.out.println("tax is:-"+inc*0.1); else
	 * System.out.println("enter positive number inc");} else {
	 * System.out.println("please enter correct gender"); } else if(inc>=500001 &&
	 * inc<=800000) System.out.println("tax is"+inc*0.2); else if(inc>800000)
	 * System.out.println("tax is"+inc*0.3); }
	 * 
	 * public static void main(String[] args) { Scanner sc=new Scanner(System.in);
	 * System.out.println("enter number "); int gennum=sc.nextInt(); Taxslabs t=new
	 * Taxslabs(); t.tax(gennum, gennum); }
	 * 
	 */
